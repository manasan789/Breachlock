class TargetPopulation extends PopulationType {

    popType;
    popol
}