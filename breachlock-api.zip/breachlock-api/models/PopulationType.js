class PopulationType {
    men;
    woman;
    children;
    boys;
    girls;
    constructor() { }
    set men(men) {
        this.men = men;
    }

    get men() {
        return this.men;
    }

    set woman(woman) {
        this.woman = woman;
    }

    get woman() {
        return this.woman;
    }

    set children(children) {
        this.children = children;
    }

    get children() {
        return this.children;
    }
    get boys() {
        return this.boys;
    }
    set boys(boys) {
        this.boys = boys;
    }

    get girls() {
        return this.girls;
    }

    set girls(girls) {
        this.girls = girls;
    }
}