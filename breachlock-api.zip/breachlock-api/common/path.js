module.exports = {
    API_DOCS: '/api-docs',
    AUTH_URL: '/auth',
    LOGIN_URL: '/login',
    API_URL: '/api',
    GET_AUTOCOMPLETE_DATA: '/automcomplete-data',
    SERVING_TYPE_JSON: './mockData/servingType.json',
    AGE_GROUP_JSON: './mockData/targetPopulation.json',
    FOOD_CATEGORY_JSON: './mockData/foodCategories.json',
    SERVING_SIZE_JSON: './mockData/servingSize.json',
    POST_PROJECT: '/project'
}