# breachlock-api
this is breachlock-api

Step to Run api code:-

# 1. git clone url.

# 2. npm install 

# 3. npm run start

# Swagger api url:- http://localhost:3000/api-docs/#/


